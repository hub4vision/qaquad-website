import { test, expect, devices } from "@playwright/test";

test.use({ ...devices["iPhone 13"] });

test.describe("Mobile navigation", () => {
  test("hamburger menu opens, lists links, and navigates", async ({ page }) => {
    await page.goto("/");

    // Desktop nav should be hidden at mobile width.
    await expect(page.getByRole("navigation", { name: "Primary" })).toBeHidden();

    const menuButton = page.getByRole("button", { name: "Open menu" });
    await expect(menuButton).toBeVisible();
    await menuButton.click();

    const mobilePanel = page.getByRole("dialog", { name: "Mobile navigation" });
    await expect(mobilePanel).toBeVisible();

    await mobilePanel.getByRole("link", { name: "How It Works" }).click();
    await expect(page).toHaveURL(/\/how-it-works/);

    // Menu should be closed after navigating.
    await expect(page.getByRole("dialog", { name: "Mobile navigation" })).toBeHidden();
  });

  test("menu closes via the close button", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Open menu" }).click();
    await expect(page.getByRole("dialog", { name: "Mobile navigation" })).toBeVisible();

    await page.getByRole("button", { name: "Close menu" }).click();
    await expect(page.getByRole("dialog", { name: "Mobile navigation" })).toBeHidden();
  });

  test("mobile menu CTA links to contact", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Open menu" }).click();
    const mobilePanel = page.getByRole("dialog", { name: "Mobile navigation" });
    await mobilePanel.getByRole("link", { name: "Book a Free QA Assessment" }).click();
    await expect(page).toHaveURL(/\/contact/);
  });
});

import { NextRequest, NextResponse } from "next/server";
import { contactFormSchema } from "@/lib/validation";
import { isRateLimited } from "@/lib/rate-limit";

export const runtime = "nodejs";

/**
 * Secure server-side contact form handler.
 *
 * - Re-validates everything with the same zod schema the client uses (never
 *   trusts client-side validation alone).
 * - Rejects honeypot hits and rate-limited IPs before doing any real work.
 * - Never echoes secrets or full lead PII back to the client, and never logs
 *   secrets (there are none to log here — no API keys touch this file's
 *   response path).
 * - Notification delivery is pluggable and fails soft: if no email/webhook
 *   provider is configured (see .env.example), the lead is still logged
 *   server-side and the visitor still gets a normal success response, so the
 *   form never appears broken. Wire up RESEND_API_KEY or LEAD_WEBHOOK_URL
 *   before real launch — see PROJECT_STATUS.md.
 */
export async function POST(request: NextRequest) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";

  if (isRateLimited(ip)) {
    return NextResponse.json(
      { ok: false, message: "Too many requests. Please try again in a minute." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, message: "Invalid request body." }, { status: 400 });
  }

  const result = contactFormSchema.safeParse(body);
  if (!result.success) {
    return NextResponse.json(
      { ok: false, message: "Please check the form for errors.", issues: result.error.flatten() },
      { status: 422 },
    );
  }

  // Honeypot: a filled "website" field means this was almost certainly
  // submitted by a bot, not a human. Respond with a generic success so the
  // bot doesn't learn its submission was detected, but never deliver or
  // store it as a real lead.
  if (result.data.website) {
    return NextResponse.json({ ok: true });
  }

  const { website: _honeypot, ...validatedFields } = result.data;
  const leadForDelivery: LeadForDelivery = {
    ...validatedFields,
    submittedAt: new Date().toISOString(),
    ip,
  };

  try {
    await deliverLead(leadForDelivery);
  } catch (error) {
    // Delivery failing (e.g. a misconfigured provider) should not surface a
    // scary error to the visitor, but it must be visible in server logs so
    // the business doesn't silently lose leads.
    console.error("[contact] lead delivery failed:", error instanceof Error ? error.message : error);
  }

  return NextResponse.json({ ok: true });
}

type LeadForDelivery = {
  name: string;
  company: string;
  email: string;
  phone?: string;
  applicationUrl?: string;
  companyType: string;
  testingRequirement: string;
  currentQaMethod: string;
  isMigrationProject: string;
  message: string;
  submittedAt: string;
  ip: string;
};

async function deliverLead(lead: LeadForDelivery) {
  const resendApiKey = process.env.RESEND_API_KEY;
  const webhookUrl = process.env.LEAD_WEBHOOK_URL;

  if (resendApiKey) {
    await sendViaResend(lead, resendApiKey);
    return;
  }

  if (webhookUrl) {
    await sendViaWebhook(lead, webhookUrl);
    return;
  }

  // No provider configured — log server-side only (never sent to the
  // client) so the lead isn't silently lost during local development or
  // before a provider is set up.
  console.log("[contact] New lead (no delivery provider configured):", {
    ...lead,
    email: redactEmail(lead.email),
  });
}

async function sendViaResend(lead: LeadForDelivery, apiKey: string) {
  const to = process.env.LEAD_NOTIFICATION_TO_EMAIL;
  const from = process.env.LEAD_NOTIFICATION_FROM_EMAIL;
  if (!to || !from) {
    throw new Error("RESEND_API_KEY is set but LEAD_NOTIFICATION_TO_EMAIL / LEAD_NOTIFICATION_FROM_EMAIL is missing.");
  }

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to,
      reply_to: lead.email,
      subject: `New QA assessment request — ${lead.company}`,
      text: formatLeadAsText(lead),
    }),
  });

  if (!response.ok) {
    throw new Error(`Resend API responded with ${response.status}`);
  }
}

async function sendViaWebhook(lead: LeadForDelivery, webhookUrl: string) {
  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: formatLeadAsText(lead), lead }),
  });

  if (!response.ok) {
    throw new Error(`Lead webhook responded with ${response.status}`);
  }
}

function formatLeadAsText(lead: LeadForDelivery) {
  return [
    `Name: ${lead.name}`,
    `Company: ${lead.company}`,
    `Email: ${lead.email}`,
    lead.phone ? `Phone: ${lead.phone}` : null,
    lead.applicationUrl ? `Application URL: ${lead.applicationUrl}` : null,
    `Company type: ${lead.companyType}`,
    `Testing requirement: ${lead.testingRequirement}`,
    `Current QA method: ${lead.currentQaMethod}`,
    `Migration project: ${lead.isMigrationProject}`,
    `Submitted: ${lead.submittedAt}`,
    "",
    "Message:",
    lead.message,
  ]
    .filter(Boolean)
    .join("\n");
}

function redactEmail(email: string) {
  const [local, domain] = email.split("@");
  if (!domain) return "***";
  return `${local.slice(0, 2)}***@${domain}`;
}

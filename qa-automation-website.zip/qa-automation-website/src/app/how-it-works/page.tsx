import type { Metadata } from "next";
import { Section } from "@/components/ui/Section";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WorkflowDiagram } from "@/components/workflow/WorkflowDiagram";
import { CTASection } from "@/components/cta/CTASection";
import { StructuredData } from "@/components/seo/StructuredData";
import { breadcrumbJsonLd, buildPageMetadata } from "@/lib/seo";
import { howItWorksSteps } from "@/lib/site-config";

const pageDescription =
  "A seven-step delivery process — Connect, Discover, Understand, Generate, Execute, Analyze, Automate — for evidence-backed QA automation.";

export const metadata: Metadata = buildPageMetadata({
  title: "How It Works",
  description: pageDescription,
  path: "/how-it-works",
});

export default function HowItWorksPage() {
  return (
    <>
      <StructuredData
        data={breadcrumbJsonLd([
          { name: "Home", path: "/" },
          { name: "How It Works", path: "/how-it-works" },
        ])}
      />

      <Section tone="dark" className="pt-16 sm:pt-20">
        <SectionHeading
          eyebrow="Delivery process"
          title="From application access to regression automation in seven steps"
          description="The same process powers every engagement, whether it's a first functional assessment or an ongoing regression partnership."
          tone="dark"
        />
      </Section>

      <Section aria-labelledby="steps-heading">
        <h2 id="steps-heading" className="sr-only">
          The seven steps
        </h2>
        <WorkflowDiagram steps={howItWorksSteps} columns={4} />
      </Section>

      <Section tone="muted" aria-labelledby="detail-heading">
        <SectionHeading id="detail-heading" eyebrow="What to expect" title="What each step looks like in practice" />
        <div className="mt-10 space-y-8">
          {howItWorksSteps.map((item) => (
            <div key={item.step} className="flex flex-col gap-2 border-b border-ink-200 pb-8 last:border-b-0 sm:flex-row sm:gap-8">
              <div className="flex-none font-mono text-sm font-semibold text-brand-600 sm:w-16">{item.step}</div>
              <div>
                <h3 className="font-semibold text-ink-900">{item.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-ink-600">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <CTASection location="how_it_works_page" />
    </>
  );
}

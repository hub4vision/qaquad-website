import type { Metadata } from "next";
import { Section } from "@/components/ui/Section";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { CTASection } from "@/components/cta/CTASection";
import { StructuredData } from "@/components/seo/StructuredData";
import { breadcrumbJsonLd, buildPageMetadata } from "@/lib/seo";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = buildPageMetadata({
  title: "About",
  description: `Why ${siteConfig.name} exists, how we approach QA, and the engineering standards behind every engagement.`,
  path: "/about",
});

const principles = [
  {
    title: "Evidence over opinion",
    description: "Every defect we report ships with the screenshot, trace, API response, or database result that supports it.",
  },
  {
    title: "Behavior over pixels",
    description: "We test what an application does for the business, not just what it looks like.",
  },
  {
    title: "Honest about maturity",
    description: "We label demo and illustrative content clearly, and never claim a capability isn't real when it is, or is real when it isn't.",
  },
  {
    title: "Engineering-led, not generic AI",
    description: "AI accelerates discovery and generation — a structured engineering process, evidence, and human review govern every finding.",
  },
];

export default function AboutPage() {
  return (
    <>
      <StructuredData
        data={breadcrumbJsonLd([
          { name: "Home", path: "/" },
          { name: "About", path: "/about" },
        ])}
      />

      <Section tone="dark" className="pt-16 sm:pt-20">
        <SectionHeading
          eyebrow="About us"
          title="A practical engineering partner for QA, not a generic AI agency"
          description="We built this company around a simple belief: releases should be validated against what the business actually needs the software to do — with evidence, not guesswork."
          tone="dark"
        />
      </Section>

      <Section aria-labelledby="story-heading">
        <div className="mx-auto max-w-3xl space-y-6 text-ink-700">
          <h2 id="story-heading" className="text-2xl font-semibold text-ink-900">
            Why we exist
          </h2>
          <p className="leading-relaxed">
            Manual regression testing doesn't scale with modern release cadence, and UI-only automation misses the
            defects that hurt the most — a calculation that's quietly wrong, a status that never updates in the
            database, a business rule that got lost in a migration. We combine AI-assisted application discovery
            with disciplined engineering practice — Playwright, API, and database validation — to catch those
            defects before your customers do.
          </p>
          <p className="leading-relaxed">
            This is a new company. We don't yet have published case studies or customer testimonials to share, and
            we'd rather say that plainly than invent them — see our{" "}
            <a href="/case-studies" className="font-semibold text-brand-700 hover:text-brand-800">
              Case Studies
            </a>{" "}
            page for what's coming.
          </p>
        </div>
      </Section>

      <Section tone="muted" aria-labelledby="principles-heading">
        <SectionHeading id="principles-heading" eyebrow="How we work" title="Our principles" />
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {principles.map((item) => (
            <div key={item.title} className="rounded-xl border border-ink-100 bg-white p-6 shadow-card">
              <h3 className="font-semibold text-ink-900">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">{item.description}</p>
            </div>
          ))}
        </div>
      </Section>

      <CTASection location="about_page" />
    </>
  );
}

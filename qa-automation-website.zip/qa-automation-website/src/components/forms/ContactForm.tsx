"use client";

import { useRef, useState } from "react";
import {
  companyTypeOptions,
  contactFormSchema,
  currentQaMethodOptions,
  migrationProjectOptions,
  testingRequirementOptions,
  type ContactFormValues,
} from "@/lib/validation";
import { trackEvent } from "@/lib/analytics";
import { clsx } from "@/lib/clsx";

type FieldErrors = Partial<Record<keyof ContactFormValues, string>>;

const initialValues: ContactFormValues = {
  name: "",
  company: "",
  email: "",
  phone: "",
  applicationUrl: "",
  companyType: "software-company",
  testingRequirement: "not-sure",
  currentQaMethod: "manual",
  isMigrationProject: "not-sure",
  message: "",
  website: "",
};

export function ContactForm() {
  const [values, setValues] = useState<ContactFormValues>(initialValues);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [serverError, setServerError] = useState<string | null>(null);
  const hasStartedRef = useRef(false);

  function handleFirstInteraction() {
    if (hasStartedRef.current) return;
    hasStartedRef.current = true;
    trackEvent("contact_form_start");
  }

  function updateField<K extends keyof ContactFormValues>(field: K, value: ContactFormValues[K]) {
    setValues((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setServerError(null);

    const result = contactFormSchema.safeParse(values);
    if (!result.success) {
      const fieldErrors: FieldErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof ContactFormValues;
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      setErrors(fieldErrors);
      // Move focus to the first invalid field for keyboard/screen-reader users.
      const firstInvalidField = Object.keys(fieldErrors)[0];
      if (firstInvalidField) {
        document.getElementById(firstInvalidField)?.focus();
      }
      return;
    }

    setErrors({});
    setStatus("submitting");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result.data),
      });

      const payload = (await response.json().catch(() => null)) as { ok?: boolean; message?: string } | null;

      if (!response.ok || !payload?.ok) {
        setStatus("error");
        setServerError(payload?.message || "Something went wrong. Please try again in a moment.");
        return;
      }

      setStatus("success");
      trackEvent("contact_form_submit", { companyType: values.companyType });
      setValues(initialValues);
    } catch {
      setStatus("error");
      setServerError("We couldn't reach the server. Please check your connection and try again.");
    }
  }

  if (status === "success") {
    return (
      <div role="status" className="rounded-2xl border border-signal-pass/30 bg-signal-pass/5 p-8 text-center">
        <h3 className="text-xl font-semibold text-ink-900">Thank you.</h3>
        <p className="mt-2 text-ink-600">We will review your requirement and contact you shortly.</p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="mt-6 text-sm font-semibold text-brand-700 hover:text-brand-800"
        >
          Submit another request
        </button>
      </div>
    );
  }

  return (
    <form noValidate onSubmit={handleSubmit} onChangeCapture={handleFirstInteraction} className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Field label="Full name" htmlFor="name" error={errors.name} required>
          <input
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            value={values.name}
            onChange={(e) => updateField("name", e.target.value)}
            className={inputClass(!!errors.name)}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? "name-error" : undefined}
          />
        </Field>

        <Field label="Company" htmlFor="company" error={errors.company} required>
          <input
            id="company"
            name="company"
            type="text"
            autoComplete="organization"
            value={values.company}
            onChange={(e) => updateField("company", e.target.value)}
            className={inputClass(!!errors.company)}
            aria-invalid={!!errors.company}
            aria-describedby={errors.company ? "company-error" : undefined}
          />
        </Field>

        <Field label="Business email" htmlFor="email" error={errors.email} required>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            value={values.email}
            onChange={(e) => updateField("email", e.target.value)}
            className={inputClass(!!errors.email)}
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? "email-error" : undefined}
          />
        </Field>

        <Field label="Phone" htmlFor="phone" error={errors.phone} hint="Optional">
          <input
            id="phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            value={values.phone}
            onChange={(e) => updateField("phone", e.target.value)}
            className={inputClass(!!errors.phone)}
          />
        </Field>

        <Field label="Application URL" htmlFor="applicationUrl" error={errors.applicationUrl} hint="Optional">
          <input
            id="applicationUrl"
            name="applicationUrl"
            type="url"
            placeholder="https://"
            value={values.applicationUrl}
            onChange={(e) => updateField("applicationUrl", e.target.value)}
            className={inputClass(!!errors.applicationUrl)}
          />
        </Field>

        <Field label="Company type" htmlFor="companyType" error={errors.companyType} required>
          <select
            id="companyType"
            name="companyType"
            value={values.companyType}
            onChange={(e) => updateField("companyType", e.target.value as ContactFormValues["companyType"])}
            className={inputClass(!!errors.companyType)}
          >
            {companyTypeOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Testing requirement" htmlFor="testingRequirement" error={errors.testingRequirement} required>
          <select
            id="testingRequirement"
            name="testingRequirement"
            value={values.testingRequirement}
            onChange={(e) => updateField("testingRequirement", e.target.value as ContactFormValues["testingRequirement"])}
            className={inputClass(!!errors.testingRequirement)}
          >
            {testingRequirementOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Current QA method" htmlFor="currentQaMethod" error={errors.currentQaMethod} required>
          <select
            id="currentQaMethod"
            name="currentQaMethod"
            value={values.currentQaMethod}
            onChange={(e) => updateField("currentQaMethod", e.target.value as ContactFormValues["currentQaMethod"])}
            className={inputClass(!!errors.currentQaMethod)}
          >
            {currentQaMethodOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Is this a migration project?" htmlFor="isMigrationProject" error={errors.isMigrationProject} required>
          <select
            id="isMigrationProject"
            name="isMigrationProject"
            value={values.isMigrationProject}
            onChange={(e) => updateField("isMigrationProject", e.target.value as ContactFormValues["isMigrationProject"])}
            className={inputClass(!!errors.isMigrationProject)}
          >
            {migrationProjectOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field label="Message" htmlFor="message" error={errors.message} required>
        <textarea
          id="message"
          name="message"
          rows={5}
          value={values.message}
          onChange={(e) => updateField("message", e.target.value)}
          className={inputClass(!!errors.message)}
          aria-invalid={!!errors.message}
          aria-describedby={errors.message ? "message-error" : undefined}
          placeholder="Tell us about your application, release cadence, and what you'd like tested."
        />
      </Field>

      {/* Honeypot: hidden from sighted users and screen readers, but present
          in the DOM (not display:none/hidden, which some spam bots skip).
          Any real visitor leaves this empty. */}
      <div aria-hidden="true" className="absolute left-[-9999px] top-auto h-px w-px overflow-hidden">
        <label htmlFor="website">Website</label>
        <input
          id="website"
          name="website"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          value={values.website}
          onChange={(e) => updateField("website", e.target.value)}
        />
      </div>

      {serverError ? (
        <p role="alert" className="rounded-lg bg-signal-fail/10 px-4 py-3 text-sm text-signal-fail">
          {serverError}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={status === "submitting"}
        className="inline-flex w-full items-center justify-center rounded-lg bg-brand-600 px-6 py-3.5 text-base font-semibold text-white shadow-card transition-colors hover:bg-brand-700 disabled:pointer-events-none disabled:opacity-60 sm:w-auto"
      >
        {status === "submitting" ? "Sending..." : "Request Free QA Assessment"}
      </button>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  error,
  hint,
  required,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-sm font-medium text-ink-800">
        {label}
        {required ? <span className="text-signal-fail"> *</span> : null}
        {hint ? <span className="ml-1 text-xs font-normal text-ink-400">({hint})</span> : null}
      </label>
      <div className="mt-1.5">{children}</div>
      {error ? (
        <p id={`${htmlFor}-error`} role="alert" className="mt-1.5 text-sm text-signal-fail">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function inputClass(hasError: boolean) {
  return clsx(
    "block w-full rounded-lg border bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-300",
    "focus:border-brand-500 focus:outline-none",
    hasError ? "border-signal-fail" : "border-ink-200",
  );
}

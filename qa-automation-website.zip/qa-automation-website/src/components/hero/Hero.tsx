import { siteConfig } from "@/lib/site-config";
import { Container } from "@/components/ui/Container";
import { CtaButton } from "@/components/cta/CtaButton";
import { VerticalFlow } from "@/components/workflow/WorkflowDiagram";

const heroFlow = ["Application", "AI QA Agent", "Browser + API + SQL", "Test Execution", "Evidence", "Defect", "Regression"];

const trustStrip = ["Playwright", "REST / API", "SQL / Database", "CI/CD", "AI-Assisted QA"];

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-ink-950">
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-grid-faint [mask-image:radial-gradient(ellipse_at_top,black,transparent_75%)]"
      />
      <Container className="relative py-20 sm:py-28">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <p className="mb-4 inline-flex items-center rounded-full border border-brand-500/30 bg-brand-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-300">
              AI-Powered QA Automation
            </p>
            <h1 className="text-4xl font-bold leading-tight text-white sm:text-5xl">
              AI-Powered QA Automation for Faster, More Reliable Software Releases
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-300">
              Discover functionality, generate meaningful tests, validate UI + API + database behavior, find defects
              with evidence, and build maintainable regression automation.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <CtaButton href={siteConfig.primaryCta.href} size="lg" trackAs="cta_click" trackProps={{ location: "hero" }}>
                {siteConfig.primaryCta.label}
              </CtaButton>
              <CtaButton
                href={siteConfig.secondaryCta.href}
                variant="secondary"
                size="lg"
                trackAs="secondary_cta_click"
                trackProps={{ location: "hero" }}
                className="border-ink-700 bg-transparent text-white hover:border-brand-400 hover:text-brand-300"
              >
                {siteConfig.secondaryCta.label}
              </CtaButton>
            </div>

            <dl className="mt-10 flex flex-wrap gap-x-8 gap-y-3">
              {trustStrip.map((item) => (
                <div key={item} className="flex items-center gap-2 text-sm text-ink-400">
                  <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                  <dt className="sr-only">Capability</dt>
                  <dd>{item}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="lg:col-span-5">
            <div className="mx-auto max-w-sm rounded-2xl border border-ink-800 bg-ink-900/60 p-5 shadow-card">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-500">From code to confidence</p>
              <VerticalFlow items={heroFlow} tone="dark" />
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}

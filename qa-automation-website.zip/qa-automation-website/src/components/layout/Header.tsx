import Link from "next/link";
import { primaryNav, siteConfig } from "@/lib/site-config";
import { NavLink } from "@/components/navigation/NavLink";
import { CtaButton } from "@/components/cta/CtaButton";
import { MobileNav } from "./MobileNav";

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-ink-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2 text-lg font-bold text-ink-900">
          <span
            aria-hidden="true"
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white"
          >
            Q
          </span>
          {siteConfig.name}
        </Link>

        <nav className="hidden md:flex md:items-center md:gap-8" aria-label="Primary">
          {primaryNav.map((item) => (
            <NavLink key={item.href} href={item.href}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden md:block">
          <CtaButton href={siteConfig.primaryCta.href} trackAs="cta_click" trackProps={{ location: "header" }}>
            {siteConfig.primaryCta.label}
          </CtaButton>
        </div>

        <MobileNav />
      </div>
    </header>
  );
}

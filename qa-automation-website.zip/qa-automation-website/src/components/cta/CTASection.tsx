import { siteConfig } from "@/lib/site-config";
import { Section } from "@/components/ui/Section";
import { CtaButton } from "./CtaButton";

export function CTASection({
  title = "Find functional gaps before your customers do.",
  description = "Book a free QA assessment and see what a functional, evidence-backed review of your application looks like.",
  location = "cta_section",
}: {
  title?: string;
  description?: string;
  location?: string;
}) {
  return (
    <Section tone="dark" aria-labelledby="cta-heading">
      <div className="flex flex-col items-start gap-6 rounded-2xl bg-gradient-to-br from-brand-900 via-ink-950 to-ink-950 p-8 sm:p-12 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-xl">
          <h2 id="cta-heading" className="text-2xl font-semibold text-white sm:text-3xl">
            {title}
          </h2>
          <p className="mt-3 text-ink-300">{description}</p>
        </div>
        <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <CtaButton href={siteConfig.primaryCta.href} size="lg" trackAs="cta_click" trackProps={{ location }}>
            {siteConfig.primaryCta.label}
          </CtaButton>
        </div>
      </div>
    </Section>
  );
}

import type { WorkflowStep } from "@/lib/site-config";
import { clsx } from "@/lib/clsx";

/**
 * Reusable step-by-step workflow visual. Used on the homepage (solution
 * section), How It Works, Migration Testing, and AI QA Agent pages so the
 * same visual language explains every workflow in the site rather than each
 * page inventing its own diagram style.
 */
export function WorkflowDiagram({
  steps,
  tone = "default",
  columns = 4,
}: {
  steps: WorkflowStep[];
  tone?: "default" | "dark";
  columns?: 3 | 4 | 5;
}) {
  const gridCols = {
    3: "sm:grid-cols-3",
    4: "sm:grid-cols-2 lg:grid-cols-4",
    5: "sm:grid-cols-2 lg:grid-cols-5",
  }[columns];

  return (
    <ol className={clsx("grid grid-cols-1 gap-4", gridCols)}>
      {steps.map((item, index) => (
        <li
          key={item.step}
          className={clsx(
            "relative flex flex-col gap-2 rounded-xl border p-5",
            tone === "dark" ? "border-ink-800 bg-ink-900" : "border-ink-100 bg-white shadow-card",
          )}
        >
          <span
            aria-hidden="true"
            className={clsx(
              "flex h-8 w-8 items-center justify-center rounded-md font-mono text-sm font-semibold",
              tone === "dark" ? "bg-brand-500/20 text-brand-300" : "bg-brand-50 text-brand-700",
            )}
          >
            {item.step}
          </span>
          <h3 className={clsx("text-base font-semibold", tone === "dark" ? "text-white" : "text-ink-900")}>
            {item.title}
          </h3>
          <p className={clsx("text-sm leading-relaxed", tone === "dark" ? "text-ink-300" : "text-ink-500")}>
            {item.description}
          </p>
          {index < steps.length - 1 ? (
            <span
              aria-hidden="true"
              className={clsx(
                "absolute -right-2 top-1/2 hidden -translate-y-1/2 sm:block",
                (index + 1) % columns === 0 && "sm:hidden",
                tone === "dark" ? "text-ink-700" : "text-ink-300",
              )}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
                <path d="M9 5l7 7-7 7-1.4-1.4L13.2 12 7.6 6.4 9 5z" />
              </svg>
            </span>
          ) : null}
        </li>
      ))}
    </ol>
  );
}

/**
 * Simple vertical funnel visual (used in the hero) showing
 * Application -> AI QA Agent -> Browser/API/SQL -> Execution -> Evidence ->
 * Defect -> Regression, per the requirements doc's hero-visual spec.
 */
export function VerticalFlow({ items, tone = "dark" }: { items: string[]; tone?: "default" | "dark" }) {
  return (
    <ol className="flex flex-col items-stretch gap-1.5">
      {items.map((item, index) => (
        <li key={item} className="flex flex-col items-center">
          <div
            className={clsx(
              "w-full rounded-lg border px-4 py-2.5 text-center text-sm font-medium",
              tone === "dark"
                ? "border-ink-700 bg-ink-800/70 text-ink-100"
                : "border-ink-200 bg-white text-ink-800",
            )}
          >
            {item}
          </div>
          {index < items.length - 1 ? (
            <svg
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="currentColor"
              className={clsx("my-0.5 h-4 w-4", tone === "dark" ? "text-ink-600" : "text-ink-300")}
            >
              <path d="M12 16.5l-6-6 1.4-1.4L12 13.7l4.6-4.6L18 10.5z" />
            </svg>
          ) : null}
        </li>
      ))}
    </ol>
  );
}

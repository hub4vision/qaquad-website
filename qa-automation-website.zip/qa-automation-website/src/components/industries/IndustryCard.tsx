import type { Industry } from "@/lib/site-config";

export function IndustryCard({ industry }: { industry: Industry }) {
  return (
    <div className="flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-6 shadow-card">
      <h3 className="text-lg font-semibold text-ink-900">{industry.name}</h3>
      <p className="mt-2 text-sm leading-relaxed text-ink-500">{industry.description}</p>
      <ul className="mt-4 space-y-2 text-sm text-ink-600">
        {industry.painPoints.map((point) => (
          <li key={point} className="flex gap-2">
            <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 flex-none rounded-full bg-brand-500" />
            <span>{point}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

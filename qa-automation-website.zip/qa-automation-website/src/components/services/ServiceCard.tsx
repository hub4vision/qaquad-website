import Link from "next/link";
import type { Service } from "@/lib/site-config";
import { Badge } from "@/components/ui/Badge";

export function ServiceCard({ service }: { service: Service }) {
  return (
    <div className="group flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-shadow hover:shadow-card-hover">
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-lg font-semibold text-ink-900">{service.name}</h3>
        <Badge tone={service.priority === "P0" ? "info" : "neutral"}>{service.priority}</Badge>
      </div>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-500">{service.shortDescription}</p>
      <Link
        href={service.href}
        className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-brand-700 group-hover:text-brand-800"
      >
        Learn more
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden="true">
          <path d="M9 5l7 7-7 7-1.4-1.4L13.2 12 7.6 6.4 9 5z" />
        </svg>
      </Link>
    </div>
  );
}

import { clsx } from "@/lib/clsx";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  id,
  className,
  tone = "default",
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  id?: string;
  className?: string;
  tone?: "default" | "dark";
}) {
  return (
    <div
      className={clsx(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
        className,
      )}
    >
      {eyebrow ? (
        <p
          className={clsx(
            "mb-3 text-sm font-semibold uppercase tracking-wide",
            tone === "dark" ? "text-brand-300" : "text-brand-600",
          )}
        >
          {eyebrow}
        </p>
      ) : null}
      <h2 id={id} className={clsx("text-3xl sm:text-4xl", tone === "dark" ? "text-white" : "text-ink-900")}>
        {title}
      </h2>
      {description ? (
        <p className={clsx("mt-4 text-lg leading-relaxed", tone === "dark" ? "text-ink-200" : "text-ink-500")}>
          {description}
        </p>
      ) : null}
    </div>
  );
}

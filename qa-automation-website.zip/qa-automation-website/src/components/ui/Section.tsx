import { clsx } from "@/lib/clsx";
import { Container } from "./Container";

type SectionProps = {
  id?: string;
  className?: string;
  containerClassName?: string;
  tone?: "default" | "muted" | "dark";
  children: React.ReactNode;
  "aria-labelledby"?: string;
};

const tones = {
  default: "bg-white",
  muted: "bg-ink-50",
  dark: "bg-ink-950 text-white",
};

export function Section({ id, className, containerClassName, tone = "default", children, ...rest }: SectionProps) {
  return (
    <section id={id} className={clsx("py-16 sm:py-20 lg:py-24", tones[tone], className)} {...rest}>
      <Container className={containerClassName}>{children}</Container>
    </section>
  );
}
